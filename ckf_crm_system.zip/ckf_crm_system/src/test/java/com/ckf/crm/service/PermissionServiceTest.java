package com.ckf.crm.service;

import com.ckf.crm.entity.Permission;
import com.ckf.crm.mapper.EmployeeMapperTest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.*;

/**
 * @author 安详的苦丁茶
 * @version 1.0
 * @date 2020/4/2 15:32
 */

@RunWith(SpringRunner.class)
@SpringBootTest
public class PermissionServiceTest {

    private Logger log = LoggerFactory.getLogger(EmployeeMapperTest.class);

    @Autowired
    private PermissionService permissionService;

    @Autowired
    private Permission permission;

    /**
     * 全查询权限
     */
    @Test
    public void selectPermissionAll() {
        List<Permission> list=permissionService.selectPermissionAll();
        for (Permission permission : list) {
            System.out.println(permission);
        }
    }

    @Test
    public void selectPermissionUrl() {

        permission = permissionService.selectPermissionUrl("/ordDelete");

        if (permission != null) {
            log.info("查询成功");
        } else {
            log.info("查询失败");
        }
    }
}