package com.ckf.crm.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ckf.crm.entity.Employee;
import com.ckf.crm.entity.Role;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author PIGS
 * @since 2020-03-23
 */

@Repository
public interface RoleMapper extends BaseMapper<Role> {

    /**
     * 添加角色
     * @param role
     * @param pId
     * @return
     */
    Integer addRole(Role role,Integer pId);



    /**
     * 分页全查询角色信息
     * @return
     */
    IPage<Role> selectRoleList(Page<Role> page);


    List<Role> selectRolePermissionAll();

    /**
     * 辅助类全查询角色和权限
     * @return
     */
    List<Role> selectRolePermissionAllVo();

}
