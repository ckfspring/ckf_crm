package com.ckf.crm.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ckf.crm.entity.EmpRole;

/**
 * @author 安详的苦丁茶
 * @version 1.0
 * @date 2020/3/28 18:33
 */
public interface EmpRoleService extends IService<EmpRole> {
}
