package com.ckf.crm.service.impl;

import com.ckf.crm.entity.Department;
import com.ckf.crm.mapper.DepartmentMapper;
import com.ckf.crm.service.DepartmentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 安详的苦丁茶
 * @since 2020-03-23
 */
@Service
@Transactional
public class DepartmentServiceImpl extends ServiceImpl<DepartmentMapper, Department> implements DepartmentService {

    @Autowired
    private DepartmentMapper departmentMapper;


    /**
     * 全查询部门信息
     * @return
     */
    @Override
    public List<Department> selectDepartmentAll() {
        return departmentMapper.selectDepartmentAll();
    }

    /**
     * 模糊查询部门经理
     * @param dName
     * @return
     */
    @Override
    public List<Department> selectDepartmentName(String dName) {
        return departmentMapper.selectDepartmentName(dName);
    }
}
