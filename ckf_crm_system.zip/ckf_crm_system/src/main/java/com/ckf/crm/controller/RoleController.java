package com.ckf.crm.controller;


import com.ckf.crm.entity.Permission;
import com.ckf.crm.entity.Role;
import com.ckf.crm.entity.RolePerm;
import com.ckf.crm.mapper.RolePermMapper;
import com.ckf.crm.service.RoleService;
import com.ckf.crm.utils.TimeUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.models.auth.In;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 安详的苦丁茶
 * @since 2020-03-23
 */
@Api(tags = "角色信息管理")
@RestController
@RequestMapping("/rol")
public class RoleController {

    /**
     * 日志
     */
    private Logger log = LoggerFactory.getLogger(EmployeeController.class);

    Map<String,Object> outMap=new HashMap<String, Object>();


    @Autowired
    private RoleService roleService;

    @Autowired
    private RolePermMapper rolePermMapper;

    @GetMapping("/goRole")
    public List<Role> roles(){

        return roleService.list();
    }


    /**
     * 执行角色全查询
     * @param page
     * @param limit
     * @return
     */
    @GetMapping("/role")
    public Map<String,Object> goRole(@RequestParam("page") Integer page, @RequestParam("limit") Integer limit){

        System.out.println("---------------进入角色信息全查询模式------------------");

        PageHelper.startPage(page,limit);

        List<Role> list=roleService.selectRolePermissionAll();

        if (list!=null){
            outMap.put("code",0);
            outMap.put("msg","查询成功");
            log.info("查询成功");

            PageInfo pageInfo = new PageInfo(list);
            outMap.put("data", pageInfo.getList());
            outMap.put("count", pageInfo.getTotal());
        }else {
            outMap.put("code",100);
            outMap.put("msg","查询失败");
            log.info("查询失败");
        }

        return outMap;
    }


    /**
     * 删除角色信息
     * @param rId
     * @return
     */
    @ApiOperation("根据ID删除部门接口")
    @ApiImplicitParam(name = "dId",value = "ID",dataType = "int")
    @DeleteMapping("/rolDelete")
    public Map<String, Object> delete(Integer rId){
        System.out.println("----------------进入删除角色信息模式-----------------");

           //获取对象修改是否删除状态
           Role role=new Role();
           role.setRId(rId);
           role.setIsDel(1);

        boolean flag =roleService.updateById(role);

        if (flag){
            log.info("删除成功");
            outMap.put("code", "200");
            System.out.println("id--"+rId);
            outMap.put("msg", "删除成功");
            return outMap;

        }else {
            outMap.put("code", "100");
            outMap.put("msg", "删除失败");
            log.info("删除失败");
        }
        return outMap;
    }


    /**
     * 添加角色信息
     * @param role
     * @return
     */
    @ApiOperation("根据ID添加角色接口")
    @PostMapping(path = "/rolAdd")
    @ResponseBody
    public Map<String, Object> add(Role role, HttpServletRequest request, Integer roleId){
        System.out.println("------------进入添加角色信息模式--------------");

        String rName = request.getParameter("rName");

        Permission per =new Permission();
        String permission = request.getParameter("permission");

        role.setCreateTime(TimeUtils.dateTime());
        role.setUpdateTime(TimeUtils.dateTime());
        role.setIsDel(0);

        //添加权限
        per.setPermission(permission);

        System.out.println("权限--"+permission);
        System.out.println("角色名称--"+rName);

         roleService.save(role);


        int rId = role.getRId();

        RolePerm rolePerm = new RolePerm(rId,roleId);
        rolePerm.setCreateTime(TimeUtils.dateTime());
        rolePerm.setUpdateTime(rolePerm.getCreateTime());
        rolePerm.setIsDel(0);

        rolePermMapper.insert(rolePerm);

        if (roleService!=null){
            log.info("添加成功");
            outMap.put("code", "200");
            outMap.put("msg", "添加成功");
        }else {
            outMap.put("code", "100");
            outMap.put("msg", "添加失败");
            log.info("添加失败");
        }
        return outMap;
    }


    /**
     * 修改角色信息
     * @param role
     * @return
     */
    @ApiOperation(value = "根据id修改角色接口")
    @PutMapping("/rolUpdate")
    @ResponseBody
    public Map<String, Object> update(Role role){
        System.out.println("----------------进入修改角色信息模式------------------");

        role.setUpdateTime(TimeUtils.dateTime());

        boolean flag = roleService.updateById(role);

        if (flag){
            log.info("修改成功");
            outMap.put("code", "200");
            outMap.put("msg", "修改成功");
        }else {
            outMap.put("code", "100");
            outMap.put("msg", "修改失败");
            log.info("修改失败");
        }
        return outMap;
    }


}
