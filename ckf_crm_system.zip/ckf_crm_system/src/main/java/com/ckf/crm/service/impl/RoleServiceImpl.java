package com.ckf.crm.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ckf.crm.entity.Role;
import com.ckf.crm.mapper.RoleMapper;
import com.ckf.crm.service.RoleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 安详的苦丁茶
 * @since 2020-03-23
 */
@Service
@Transactional
public class RoleServiceImpl extends ServiceImpl<RoleMapper, Role> implements RoleService {

    @Autowired
    private RoleMapper roleMapper;


    @Override
    public Integer addRole(Role role, Integer pId) {
        return roleMapper.addRole(role,pId);
    }

    @Override
    public IPage<Role> selectRoleList(Page<Role> page) {
        return roleMapper.selectRoleList(page);
    }

    @Override
    public List<Role> selectRolePermissionAll() {
        return roleMapper.selectRolePermissionAll();
    }


    @Override
    public List<Role> selectRolePermissionAllVo() {
        return roleMapper.selectRolePermissionAllVo();
    }
}
