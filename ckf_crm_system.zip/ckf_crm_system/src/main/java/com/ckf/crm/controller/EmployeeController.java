package com.ckf.crm.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ckf.crm.entity.Employee;
import com.ckf.crm.service.EmployeeService;
import com.ckf.crm.utils.ShiroUtils;
import com.ckf.crm.utils.TimeUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.apache.ibatis.annotations.Param;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 安详的苦丁茶
 * @since 2020-03-23
 */
@Api(tags = "员工信息管理")
@RestController
@RequestMapping("emp")
public class EmployeeController {

    /**
     * 日志
     */
    private Logger log = LoggerFactory.getLogger(EmployeeController.class);

    Map<String,Object> outMap=new HashMap<String, Object>();

    @Autowired
    private EmployeeService employeeService;


    /**
     * 全查询员工信息
     * @param page
     * @param limit
     * @return
     */
    @ApiOperation(value = "员工查询接口")
    @GetMapping("/employee")
    public Map<String,Object> goEmployee(Integer page,Integer limit){
        System.out.println("---------------进入员工信息全查询模式------------------");

        Map<String,Object> map = new HashMap<String,Object> ();

        //设置mybatisPlus分页
        Page<Employee> p = new Page<Employee>();
        p.setSize(limit);       //设置每页记录数
        p.setCurrent(page);     //设置当前页码

        IPage<Employee> iPage = employeeService.selectList(p);

        map.put("msg","查询情况");
        map.put("count",iPage.getTotal());
        map.put("data",iPage.getRecords());
        map.put("code",0);

        return map;
    }


    /**
     * 模糊查询员姓名
     * @param page
     * @param limit
     * @param request
     * @return
     */
    @ApiOperation(value = "模糊查询员工姓名接口")
    @GetMapping("/empSearchName")
    @ResponseBody
    public Map<String, Object> searchName(@RequestParam("page") Integer page, @RequestParam("limit") Integer limit, HttpServletRequest request) {

        System.out.println("-------------------进入模糊查询员工姓名模式------------------");

        System.out.println(page + " -- " + limit);
        PageHelper.startPage(page, limit);

        String eName = request.getParameter("nameSearch");
        System.out.println("name:" + eName);

        List<Employee> list = employeeService.selectEmployeeName(eName);

        if (list != null) {
            log.info("模糊查询成功");
            outMap.put("EmployeeName", list);
            outMap.put("code", 0);
            outMap.put("fuzzyQuerySucceed ", "模糊查询成功");

            PageInfo pageInfo = new PageInfo(list);
            System.out.println("数据-- " + pageInfo);

            outMap.put("data", pageInfo.getList());
            outMap.put("count", pageInfo.getTotal());

            return outMap;
        } else {
            outMap.put("code", 100);
            log.info("模糊查询失败");
            outMap.put("fuzzyQueryDefeated", "模糊查询失败");
        }
        return outMap;
    }



    /**
     * 删除用户信息
     * @param eId
     * @return
     */
    @ApiOperation(value = "根据ID删除用户的接口")
    @ApiImplicitParam(name = "eId",value = "用户ID",dataType = "int")
    @DeleteMapping("/empDelete")
    public Map<String, Object> delete(Integer eId){
        System.out.println("----------------进入删除员工信息模式-----------------");

        Employee employee=new Employee();
        employee.setEId(eId);
        employee.setIsDel(1);

        boolean flag = employeeService.updateById(employee);

        if (flag){
            outMap.put("code", "200");
            System.out.println("id--"+eId);
            outMap.put("msg", "删除成功");
            log.info("删除成功");
            return outMap;

        }else {
            outMap.put("code", "100");
            outMap.put("msg", "删除失败");
            log.info("删除失败");
        }
        return outMap;
    }



    /**
     * 添加员工
     *
     * @param employee
     * @return
     */
    @ApiOperation(value = "根据ID添加员工信息接口")
    @PostMapping(path = "/empAdd")
    @ResponseBody
    public Map<String, Object> add(Employee employee,Integer roleId) {
        System.out.println("------------进入员工添加信息模式--------------");
        log.info("employee={}",employee);
        log.info("roleId={}",roleId);

        Integer flag = employeeService.addEmployee(employee, roleId);

        if (flag>0) {
            outMap.put("code", "200");
            log.info("添加成功");
            outMap.put("msg", "添加成功");

        } else {
            log.info("添加失败");
            outMap.put("code", "100");
            outMap.put("msg", "添加失败");
        }
        return outMap;
    }



    /**
     * 修改员工
     *
     * @param employee
     * @return
     */
    @ApiOperation(value = "根据ID修改员工信息接口")
    @PutMapping("/empUpdate")
    @ResponseBody
    public Map<String, Object> update(Employee employee,Integer roleId) {
        System.out.println("----------------进入员工修改模式------------------");

        Integer flag = employeeService.updateEmployee(employee,roleId);

        if (flag>0) {
            outMap.put("code", "200");
            outMap.put("msg", "修改成功");
            log.info("修改成功");
        } else {
            outMap.put("code", "100");
            outMap.put("msg", "修改失败");
            log.info("修改失败");
        }
        return outMap;
    }



}
