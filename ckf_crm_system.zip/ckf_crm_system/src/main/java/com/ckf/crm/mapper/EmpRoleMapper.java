package com.ckf.crm.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ckf.crm.entity.EmpRole;
import org.springframework.stereotype.Repository;

@Repository
public interface EmpRoleMapper extends BaseMapper<EmpRole> {

}
