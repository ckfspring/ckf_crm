package com.ckf.crm.mapper;

import com.ckf.crm.entity.Permission;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author PIGS
 * @since 2020-03-23
 */

@Repository
public interface PermissionMapper extends BaseMapper<Permission> {

    /**
     * 全查询权限信息
     * @return
     */
    List<Permission> selectPermissionAll();


}
