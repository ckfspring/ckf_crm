package com.ckf.crm.service.impl;

import com.baomidou.mybatisplus.core.conditions.AbstractWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ckf.crm.entity.EmpRole;
import com.ckf.crm.entity.Employee;
import com.ckf.crm.mapper.EmpRoleMapper;
import com.ckf.crm.mapper.EmployeeMapper;
import com.ckf.crm.service.EmpRoleService;
import com.ckf.crm.service.EmployeeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ckf.crm.utils.ShiroUtils;
import com.ckf.crm.utils.TimeUtils;
import org.apache.shiro.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author 安详的苦丁茶
 * @since 2020-03-23
 */
@Service
@Transactional
public class EmployeeServiceImpl extends ServiceImpl<EmployeeMapper, Employee> implements EmployeeService {

    @Autowired
    private EmployeeMapper employeeMapper;

    @Autowired
    private EmpRoleMapper empRoleMapper;

    @Autowired
    private EmpRoleService empRoleService;

    private Logger logger = LoggerFactory.getLogger(EmployeeServiceImpl.class);


    /**
     * 分页全查询
     *
     * @param page
     * @return
     */
    @Override
    public IPage<Employee> selectList(Page<Employee> page) {
        return employeeMapper.selectList(page);
    }



    /**
     * 分页全查询员工信息
     * @return
     */
    @Override
    public List<Employee> selectEmployeeName(String eName) {
        return employeeMapper.selectEmployeeName(eName);
    }

    /**
     * 根据用户查询 授权
     *
     * @param userName
     * @return
     */
    @Override
    public Employee selectByUserName(String userName) {
        return employeeMapper.selectByUserName(userName);
    }


    /**
     * 查询用户名是否存在
     *
     * @param eName
     * @return
     */
    @Override
    public Employee selectName(String eName) {
        return employeeMapper.selectName(eName);
    }


    /**
     * 注册
     *
     * @param employee
     * @return
     */
    @Override
    public Integer register(Employee employee) {
        return employeeMapper.register(employee);
    }


    /**
     * 添加员工
     * @param employee
     * @param roleId
     * @return
     */
    @Override
    public Integer addEmployee(Employee employee, Integer roleId) {
        System.out.println("-------------service 进入员工添加-------------");
        /**
         * 1.获取盐
         * 2.shiro加盐加密
         * 3.用户信息存入对象，插入数据库，获取到插入的id
         * 4.将empId和roleId插入到emp_role表中
         */
        //从ShiroUtils类中随机生成盐
        employee.setSalt(ShiroUtils.randomSalt());

        //将密码设置为 加密后的密码（由ShiroUtils里面encryptPassword方法实现）
        employee.setEPwd(ShiroUtils.encryptPassword(employee.getEPwd(),employee.getCredentialsSalt()));

        employee.setCreateTime(TimeUtils.dateTime());
        employee.setUpdateTime(employee.getCreateTime());  //获取创建时间，可以提高一点性能
        employee.setIsDel(0);
        int result =  employeeMapper.insert(employee);

        int empId = employee.getEId();  //获取插入自增的id
        //将empId和roleId一同插入到  员工与角色关系表
        EmpRole empRole = new EmpRole(empId,roleId);
        empRole.setCreateTime(TimeUtils.dateTime());
        empRole.setUpdateTime(empRole.getCreateTime());
        empRole.setIsDel(0);

        empRoleMapper.insert(empRole);

        return result;
    }


    /**
     *  修改员工
     * @param employee
     * @param roleId
     * @return
     */
    @Override
    public Integer updateEmployee(Employee employee, Integer roleId) {
        System.out.println("-------------service 进入员工修改-------------");

        //判断用户是否输入密码，如果没有，获取的就是空字符串 ("")  就不修改密码
        if (!"".equals(employee.getEPwd())) {
            //从ShiroUtils类中随机生成盐
            employee.setSalt(ShiroUtils.randomSalt());
            //将密码设置为 加密后的密码（由ShiroUtils里面encryptPassword方法实现）
            employee.setEPwd(ShiroUtils.encryptPassword(employee.getEPwd(), employee.getCredentialsSalt()));
        } else {
            employee.setEPwd(null);
        }

        System.out.println("ok");

        //设置时间
        employee.setUpdateTime(TimeUtils.dateTime());

        //将信息更新到数据库中（空的属性不修改）
        int result = employeeMapper.updateById(employee);

        EmpRole empRole = new EmpRole(employee.getEId(), roleId);

        empRole.setUpdateTime(TimeUtils.dateTime());
        AbstractWrapper wrapper = new QueryWrapper();
        System.out.println("ok2");
        wrapper.eq("emp_id", employee.getEId());

        System.out.println("ok3");
        empRoleMapper.update(empRole, wrapper);
        System.out.println("ok4");
        return result;
    }


}
