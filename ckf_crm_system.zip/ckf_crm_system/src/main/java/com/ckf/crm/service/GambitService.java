package com.ckf.crm.service;

import com.ckf.crm.entity.Gambit;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 安详的苦丁茶
 * @since 2020-03-27
 */
public interface GambitService extends IService<Gambit> {

    /**
     * 全查询文章信息
     * @return
     */
    List<Gambit> selectGambitAll();



    /**
     * 模糊查询话题创建人姓名
     * @param gName
     * @return
     */
    List<Gambit> selectGambitName(String gName);

}
