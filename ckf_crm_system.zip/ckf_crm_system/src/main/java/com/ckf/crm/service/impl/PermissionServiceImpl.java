package com.ckf.crm.service.impl;

import com.ckf.crm.entity.Permission;
import com.ckf.crm.mapper.PermissionMapper;
import com.ckf.crm.service.PermissionService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 安详的苦丁茶
 * @since 2020-03-23
 */
@Service
@Transactional
public class PermissionServiceImpl extends ServiceImpl<PermissionMapper, Permission> implements PermissionService {

    @Autowired
    private PermissionMapper permissionMapper;


    /**
     * 全查询权限信息
     * @return
     */
    @Override
    public List<Permission> selectPermissionAll() {
        return permissionMapper.selectPermissionAll();
    }


}
