package com.ckf.crm.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ckf.crm.entity.Employee;
import com.ckf.crm.entity.Role;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 安详的苦丁茶
 * @since 2020-03-23
 */
public interface RoleService extends IService<Role> {


    /**
     * 添加角色
     * @param role
     * @param pId
     * @return
     */
    Integer addRole(Role role,Integer pId);


    /**
     * 分页全查询角色信息
     * @return
     */
    IPage<Role> selectRoleList(Page<Role> page);



    List<Role> selectRolePermissionAll();

    /**
     * 辅助类全查询角色和权限
     * @return
     */
    List<Role> selectRolePermissionAllVo();

}
