package com.ckf.crm.controller;


import com.ckf.crm.entity.Department;
import com.ckf.crm.entity.Employee;
import com.ckf.crm.service.DepartmentService;
import com.ckf.crm.utils.TimeUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author安详的苦丁茶
 * @since 2020-03-23
 */

@Api(tags = "部门信息管理")
@RestController
@RequestMapping("/dep")
public class DepartmentController {

    /**
     * 日志
     */
    private Logger log = LoggerFactory.getLogger(EmployeeController.class);

    Map<String,Object> outMap=new HashMap<String, Object>();


    @Autowired
    private DepartmentService departmentService;

    /**
     * 查询部门信息
     * @param page
     * @param limit
     * @return
     */
    @ApiOperation("查询部门信息接口")
    @GetMapping("/department")
    public Map<String,Object> goDepartment(@RequestParam("page") Integer page, @RequestParam("limit") Integer limit){

        System.out.println("---------------进入部门信息全查询模式------------------");

        PageHelper.startPage(page,limit);

        List<Department> list=departmentService.selectDepartmentAll();

        if (list!=null){
            outMap.put("code",0);
            log.info("查询成功");
            outMap.put("msg","查询成功");

            PageInfo pageInfo = new PageInfo(list);
            outMap.put("data", pageInfo.getList());
            outMap.put("count", pageInfo.getTotal());
        }else {
            outMap.put("code",100);
            outMap.put("msg","查询失败");
            log.info("查询失败");
        }

        return outMap;
    }


    /**
     * 模糊查询部门经理姓名
     * @param page
     * @param limit
     * @param request
     * @return
     */
    @ApiOperation(value = "模糊查询部门经理姓名接口")
    @GetMapping("/depSearchName")
    @ResponseBody
    public Map<String, Object> searchName(@RequestParam("page") Integer page, @RequestParam("limit") Integer limit, HttpServletRequest request) {

        System.out.println("-------------------进入模糊查询部门经理姓名模式------------------");

        System.out.println(page + " -- " + limit);
        PageHelper.startPage(page, limit);

        String dName = request.getParameter("nameSearch");
        System.out.println("name:" + dName);

        List<Department> list = departmentService.selectDepartmentName(dName);

        if (list != null) {
            outMap.put("DepartmentName", list);
            outMap.put("code", 0);
            log.info("模糊查询成功");
            outMap.put("fuzzyQuerySucceed ", "模糊查询成功");

            PageInfo pageInfo = new PageInfo(list);
            log.info("数据-- " + pageInfo);

            outMap.put("data", pageInfo.getList());
            outMap.put("count", pageInfo.getTotal());

            return outMap;
        } else {
            outMap.put("code", 100);
            log.info("模糊查询失败");
            outMap.put("fuzzyQueryDefeated", "模糊查询失败");
        }
        return outMap;
    }



    /**
     * 删除部门信息
     * @param dId
     * @return
     */
    @ApiOperation("根据ID删除部门接口")
    @ApiImplicitParam(name = "dId",value = "ID",dataType = "int")
    @DeleteMapping("/depDelete")
    public Map<String, Object> delete(Integer dId){
        System.out.println("----------------进入删除部门信息模式-----------------");

        Department department=new Department();
        department.setDId(dId);
        department.setIsDel(1);

        boolean flag =departmentService.updateById(department);

        if (flag){
            outMap.put("code", "200");
            log.info("id--"+dId);
            log.info("删除成功");
            outMap.put("msg", "删除成功");
            return outMap;

        }else {
            outMap.put("code", "100");
            outMap.put("msg", "删除失败");
            log.info("删除失败");
        }
        return outMap;
    }


    /**
     * 添加部门信息
     * @param department
     * @return
     */
    @ApiOperation("根据id添加部门接口")
    @PostMapping(path = "/depAdd")
    @ResponseBody
    public Map<String, Object> add(Department department){
        System.out.println("------------进入添加部门信息模式--------------");

        department.setCreateTime(TimeUtils.dateTime());
        department.setUpdateTime(TimeUtils.dateTime());
        department.setIsDel(0);

        boolean flag = departmentService.save(department);

        if (flag){
            outMap.put("code", "200");
            outMap.put("msg", "添加成功");
            log.info("添加成功");
        }else {
            outMap.put("code", "100");
            outMap.put("msg", "添加失败");
            log.info("添加失败");
        }
        return outMap;
    }


    /**
     * 修改部门信息
     * @param department
     * @return
     */
    @ApiOperation(value = "根据id修改部门接口")
    @PutMapping("/depUpdate")
    @ResponseBody
    public Map<String, Object> update(Department department){
        System.out.println("----------------进入修改部门信息模式------------------");

        department.setUpdateTime(TimeUtils.dateTime());

        boolean flag = departmentService.updateById(department);

        if (flag){
            outMap.put("code", "200");
            outMap.put("msg", "修改成功");
            log.info("修改成功");
        }else {
            outMap.put("code", "100");
            outMap.put("msg", "修改失败");
            log.info("修改失败");
        }
        return outMap;
    }

}
