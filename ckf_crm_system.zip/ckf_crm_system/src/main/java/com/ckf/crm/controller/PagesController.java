package com.ckf.crm.controller;

import io.swagger.annotations.Api;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * @author 安详的苦丁茶
 * @version 1.0
 * @date 2020/3/23 20:21
 */

@Api(tags = "页面跳转管理")
@Controller
public class PagesController {

    @GetMapping("/login")
    public String login(){
        return "login";
    }

    @GetMapping("/backstageIndex")
    public String backstage_index(){
        return "backstageIndex";

    }


    @GetMapping("/empAdd")
    public String empAdd(){
        return "empAdd";

    }

    @GetMapping("/empUpdate")
    public String empUpdate(){
        return "empUpdate";

    }

    @GetMapping("/empDelete")
    public String empDelete(){
        return "empDelete";

    }

    @GetMapping("/department")
    public String department(){
        return "department";
    }


    @GetMapping("/role")
    public String role(){
        return "role";
    }


    @GetMapping("/consult")
    public String consult(){
        return "consult";
    }

    @GetMapping("/consultList")
    public String consultList(){
        return "consultList";
    }

    @GetMapping("/gambit")
    public String gambit(){
        return "gambit";
    }

    @GetMapping("/permission")
    public String permission(){
        return "/permission";
    }


    @GetMapping("403")
    public String noRights(){
        return "403";
    }

}
