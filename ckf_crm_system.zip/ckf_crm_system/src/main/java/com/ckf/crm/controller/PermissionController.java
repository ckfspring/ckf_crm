package com.ckf.crm.controller;

import com.ckf.crm.entity.Permission;
import com.ckf.crm.service.PermissionService;
import com.ckf.crm.utils.TimeUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author安详的苦丁茶
 * @since 2020-03-23
 */
@Api(tags = "权限信息管理")
@RestController
@RequestMapping("/per")
public class PermissionController {

    private Logger log = LoggerFactory.getLogger(LoginRegisterController.class);

    @Autowired
    private PermissionService permissionService;


    Map<String,Object> outMap=new HashMap<String, Object>();

    /**
     * 查询权限信息
     * @param page
     * @param limit
     * @return
     */
    @GetMapping("/permission")
    public Map<String,Object> goDepartment(@RequestParam("page") Integer page, @RequestParam("limit") Integer limit){

        System.out.println("---------------进入权限信息全查询模式------------------");

        PageHelper.startPage(page,limit);

        List<Permission> list=permissionService.selectPermissionAll();

        if (list!=null){
            log.info("查询成功");
            outMap.put("code",0);
            outMap.put("msg","查询成功");

            PageInfo pageInfo = new PageInfo(list);
            outMap.put("data", pageInfo.getList());
            outMap.put("count", pageInfo.getTotal());
        }else {
            outMap.put("code",100);
            outMap.put("msg","查询失败");
            log.info("查询失败");
        }

        return outMap;
    }



    /**
     * 删除权限信息
     * @param pId
     * @return
     */
    @ApiOperation("根据ID删除部门接口")
    @ApiImplicitParam(name = "pId",value = "ID",dataType = "int")
    @DeleteMapping("/perDelete")
    public Map<String, Object> delete(Integer pId){
        System.out.println("----------------进入删除权限信息模式-----------------");

        //获取对象修改是否删除状态
        Permission permission=new Permission();
        permission.setPId(pId);
        permission.setIsDel(1);

        boolean flag =permissionService.updateById(permission);

        if (flag){
            log.info("id--"+pId);
            outMap.put("code", "200");
            log.info("删除成功");
            outMap.put("msg", "删除成功");
            return outMap;

        }else {
            outMap.put("code", "100");
            outMap.put("msg", "删除失败");
            log.info("删除失败");
        }
        return outMap;
    }


    /**
     * 添加权限信息
     * @param permission
     * @return
     */
    @ApiOperation("根据id添加权限的接口")
    @PostMapping(path = "/perAdd")
    @ResponseBody
    public Map<String, Object> add(Permission permission, HttpServletRequest request){
        System.out.println("------------进入添加权限信息模式--------------");

        //获取参数
        String permName = request.getParameter("permName");
        String permiss = request.getParameter("permission");
        String url = request.getParameter("url");

        //打印数据到控制台
        System.out.println("权限名称--"+permName);
        System.out.println("权限--"+permiss);
        System.out.println("url"+url);

        permission.setCreateTime(TimeUtils.dateTime());
        permission.setUpdateTime(TimeUtils.dateTime());
        permission.setIsDel(0);

        boolean flag = permissionService.save(permission);

        if (flag){
            outMap.put("code", "200");
            log.info("添加成功");
            outMap.put("msg", "添加成功");

        }else {
            outMap.put("code", "100");
            outMap.put("msg", "添加失败");
            log.info("添加失败");
        }
        return outMap;
    }


    /**
     * 修改权限信息
     * @param permission1
     * @return
     */
    @ApiOperation(value = "根据id修改权限接口")
    @PutMapping("/perUpdate")
    @ResponseBody
    public Map<String, Object> update(Permission permission1,HttpServletRequest request){
        System.out.println("----------------进入修改权限信息模式------------------");

        //获取参数
        String permission = request.getParameter("permission");
        String permName = request.getParameter("permName");
        String url =  request.getParameter("url");
        String createTime = request.getParameter("createTime");

        //打印数据到控制台
        System.out.println("权限名称--"+permName);
        System.out.println("权限--"+permission);
        System.out.println("url--"+url);
        System.out.println("创建时间"+createTime);

        permission1.setUpdateTime(TimeUtils.dateTime());
        permission1.setIsDel(0);

        boolean flag = permissionService.updateById(permission1);

        if (flag){
            outMap.put("code", "200");
            log.info("修改成功");
            outMap.put("msg", "修改成功");
        }else {
            outMap.put("code", "100");
            outMap.put("msg", "修改失败");
            log.info("修改失败");
        }
        return outMap;
    }

}
