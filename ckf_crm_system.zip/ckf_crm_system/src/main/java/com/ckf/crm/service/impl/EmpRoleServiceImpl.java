package com.ckf.crm.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ckf.crm.entity.EmpRole;
import com.ckf.crm.mapper.EmpRoleMapper;
import com.ckf.crm.service.EmpRoleService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author 安详的苦丁茶
 * @version 1.0
 * @date 2020/3/28 18:34
 */

@Service
@Transactional
public class EmpRoleServiceImpl extends ServiceImpl<EmpRoleMapper, EmpRole> implements EmpRoleService {

}
