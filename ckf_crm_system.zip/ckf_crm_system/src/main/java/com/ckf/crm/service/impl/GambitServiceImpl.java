package com.ckf.crm.service.impl;

import com.ckf.crm.entity.Gambit;
import com.ckf.crm.mapper.GambitMapper;
import com.ckf.crm.service.GambitService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 安详的苦丁茶
 * @since 2020-03-27
 */
@Service
@Transactional
public class GambitServiceImpl extends ServiceImpl<GambitMapper, Gambit> implements GambitService {


    @Autowired
    private GambitMapper gambitMapper;


    /**
     * 全查询文章信息
     * @return
     */
    @Override
    public List<Gambit> selectGambitAll() {
        return gambitMapper.selectGambitAll();
    }

    /**
     * 模糊查询话题创建人姓名
     * @param gName
     * @return
     */
    @Override
    public List<Gambit> selectGambitName(String gName) {
        return gambitMapper.selectGambitName(gName);
    }
}
