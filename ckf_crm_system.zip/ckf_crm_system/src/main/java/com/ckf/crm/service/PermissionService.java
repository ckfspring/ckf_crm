package com.ckf.crm.service;

import com.ckf.crm.entity.Permission;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 安详的苦丁茶
 * @since 2020-03-23
 */
public interface PermissionService extends IService<Permission> {

    /**
     * 全查询权限信息
     * @return
     */
    List<Permission> selectPermissionAll();

}
