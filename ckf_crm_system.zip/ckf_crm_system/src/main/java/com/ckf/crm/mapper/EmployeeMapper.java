package com.ckf.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ckf.crm.entity.Employee;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface EmployeeMapper extends BaseMapper<Employee> {


    /**
     * 分页全查询
     * @return
     */
    IPage<Employee> selectList(Page<Employee> page);


    /**
     * 根据员工姓名模糊查询
     * @param eName
     * @return
     */
    List<Employee> selectEmployeeName(String eName);

    /**
     * 根据用户查询 授权
     * @param userName
     * @return
     */
    Employee selectByUserName(String userName);


    /**
     * 查询用户名是否存在
     * @param eName
     * @return
     */
    public Employee selectName(@Param("eName") String eName);


    /**
     * 注册
     * @param employee
     * @return
     */
    Integer register(Employee employee);



}
