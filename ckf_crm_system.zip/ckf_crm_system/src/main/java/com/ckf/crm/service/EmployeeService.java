package com.ckf.crm.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ckf.crm.entity.Employee;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 安详的苦丁茶
 * @since 2020-03-23
 */
public interface EmployeeService extends IService<Employee> {


    /**
     * 分页全查询员工信息
     * @return
     */
    IPage<Employee> selectList(Page<Employee> page);

    /**
     * 根据员工姓名模糊查询
     * @param eName
     * @return
     */
    List<Employee> selectEmployeeName(String eName);


    /**
     * 根据用户查询 授权
     * @param userName
     * @return
     */
    Employee selectByUserName(String userName);


    /**
     * 查询用户名是否存在
     * @param eName
     * @return
     */
    public Employee selectName(String eName);

    /**
     * 注册
     * @param employee
     * @return
     */
    Integer register(Employee employee);

    /**
     * 添加员工
     * @param employee
     * @param rId
     * @return
     */
     Integer addEmployee(Employee employee,Integer rId);

    /**
     * 修改员工
     * @param employee
     * @return
     */
    Integer updateEmployee(Employee employee,Integer rId);


}
